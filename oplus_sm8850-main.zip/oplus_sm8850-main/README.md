# SM8850 系列通用6.12内核自动化编译脚本
[![STAR](https://img.shields.io/github/stars/edmory/oplus_sm8850?style=flat&logo=data%3Aimage%2Fsvg%2Bxml%3Bbase64%2CPHN2ZyByb2xlPSJpbWciIHZpZXdCb3g9IjAgMCAyNCAyNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48dGl0bGU%2BR2l0SHViPC90aXRsZT48cGF0aCBkPSJNMTIgLjI5N2MtNi42MyAwLTEyIDUuMzczLTEyIDEyIDAgNS4zMDMgMy40MzggOS44IDguMjA1IDExLjM4NS42LjExMy44Mi0uMjU4LjgyLS41NzcgMC0uMjg1LS4wMS0xLjA0LS4wMTUtMi4wNC0zLjMzOC43MjQtNC4wNDItMS42MS00LjA0Mi0xLjYxQzQuNDIyIDE4LjA3IDMuNjMzIDE3LjcgMy42MzMgMTcuN2MtMS4wODctLjc0NC4wODQtLjcyOS4wODQtLjcyOSAxLjIwNS4wODQgMS44MzggMS4yMzYgMS44MzggMS4yMzYgMS4wNyAxLjgzNSAyLjgwOSAxLjMwNSAzLjQ5NS45OTguMTA4LS43NzYuNDE3LTEuMzA1Ljc2LTEuNjA1LTIuNjY1LS4zLTUuNDY2LTEuMzMyLTUuNDY2LTUuOTMgMC0xLjMxLjQ2NS0yLjM4IDEuMjM1LTMuMjItLjEzNS0uMzAzLS41NC0xLjUyMy4xMDUtMy4xNzYgMCAwIDEuMDA1LS4zMjIgMy4zIDEuMjMuOTYtLjI2NyAxLjk4LS4zOTkgMy0uNDA1IDEuMDIuMDA2IDIuMDQuMTM4IDMgLjQwNSAyLjI4LTEuNTUyIDMuMjg1LTEuMjMgMy4yODUtMS4yMy42NDUgMS42NTMuMjQgMi44NzMuMTIgMy4xNzYuNzY1Ljg0IDEuMjMgMS45MSAxLjIzIDMuMjIgMCA0LjYxLTIuODA1IDUuNjI1LTUuNDc1IDUuOTIuNDIuMzYuODEgMS4wOTYuODEgMi4yMiAwIDEuNjA2LS4wMTUgMi44OTYtLjAxNSAzLjI4NiAwIC4zMTUuMjEuNjkuODI1LjU3QzIwLjU2NSAyMi4wOTIgMjQgMTcuNTkyIDI0IDEyLjI5N2MwLTYuNjI3LTUuMzczLTEyLTEyLTEyIiBmaWxsPSIjZmZmZmZmIj48L3BhdGg%2BPC9zdmc%2B)](https://github.com/edmory/oplus_sm8850/stargazers)
[![FORK](https://img.shields.io/github/forks/edmory/oplus_sm8850?style=flat&logo=greasyfork&color=%2394E61A)](https://github.com/edmory/oplus_sm8850/forks)
[![COOLAPK](https://img.shields.io/badge/EdMory-EdMory?style=flat&logo=android&logoColor=FF4500&label=%E9%85%B7%E5%AE%89&color=FF4500)](http://www.coolapk.com/u/983818)
[![DISCUSSION](https://img.shields.io/badge/%E8%AE%A8%E8%AE%BA%E5%8C%BA-discussions?logo=livechat&logoColor=FFBBFF&color=3399ff)](https://github.com/edmory/oplus_sm8850/discussions)

##### 
一个更方便、快捷的自动化OPPO/一加/真我系列骁龙8Elite Gen5(SM8850)机型的通用6.12内核编译脚本。
##### 
这个项目的初衷是解决以下问题：
- 绿厂官方摆烂，代码开源开一半，导致部分内核代码无法通过已有的配置xml正常编译，甚至没有编译配置xml；
- 由于6.12内核引入了包括rust代码在内的大量新机制，导致市面上已有的使用make指令编译内核的方法无法正常完成编译，只能使用低效的bazel进行编译，而官方使用的 Bazel 编译器过于不稳定且臃肿不堪，容易出现各种各样莫名其妙的错误，且全网几乎找不到任何有效解决方法，对于新手极不友好；
- 现有的6.12内核常用编译流程（使用bazel编译/拉取第三方工具链编译等）编译速度极慢，即使在有缓存的情况下二次编译时间也动辄需要20-30分钟，且bazel与ccache缓存不兼容，无法正常保存编译缓存。
## 本项目的主要内容
- [x] 使用 AOSP 官方 LLVM/Clang 19 + Rust v1.82.0 进行编译，大幅优化编译流程并引入ccache缓存机制，对比原 bazel 编译器缩短了近2/3的编译时间（原版官方编译器每次约需要超过1h才能完成编译），提高了编译过程的稳定性，输出日志更便于维护调试；
- [x] 修复官方代码未及时更新的补丁，并引入诸多第三方功能支持；
- [x] 提供 Github Action 在线编译脚本。
- [x] 骁龙 SM8850 通用GKI内核（基于谷歌源码的 6.12.69 ，其他同内核版本非SM8850机型可自行测试，部分机型可完全兼容）
- [x] [BakaSU](https://github.com/Baka-SU/BakaSU)/[KowSU](https://github.com/KOWX712/KernelSU)/原版[KernelSU](https://github.com/tiann/KernelSU)多版本KSU可选
- [x] cctv18独家设计的 [ccache-ECS](https://github.com/cctv18/ccache-ECS) 缓存及大量编译流程优化，编译时间可稳定在约6min *(首次编译时会拉取公共预置ccache，从第二次开始没有大量配置改动的情况下，单次编译时间约6min；距离上一次调用两周未调用后缓存会被自动清除，此时编译会自动重建缓存)*
- [x] 引入[Optprobe](https://lkml.rescloud.iu.edu/hypermail/linux/kernel/2503.3/02174.html)
- [x] LZ4 1.11.0 & ZSTD 1.5.8 算法更新&优化补丁(来自[@ferstar](https://github.com/ferstar), 移植by [@Xiaomichael](https://github.com/Xiaomichael), 6.12版本补丁重制by [@cctv18](https://github.com/cctv18))
- [x] 移植LZ4KD支持到6.12内核(可选补丁)
- [x] 可选加入 [BBR](https://github.com/CachyOS/linux/commits/6.16/bbr3),[BRUTAL](https://github.com/HyNetworks/tcp-brutal) 及一系列 TCP 拥塞控制算法，设置BBR3为默认拥塞算法，FQ_CODEL为默认队列算法以优化网络延迟环境下的表现
- [x] 移植[LE9UO](https://github.com/brokestar233/android_kernel_common_sm8850/commit/ba01e007572c91596e7ef0b78d2b16932f94adb3),[Kcompressd-Unofficial](https://github.com/brokestar233/android_kernel_common_sm8850/commit/8cb44929a08b2ca19a7711f3b510d5451726bb3a)支持到6.12内核(可选补丁)
- [x] [INTFP](https://github.com/firelzrd/intfp),[ISQRT](https://github.com/firelzrd/isqrt)移植(可选补丁)
- [x] [ADIOS](https://github.com/firelzrd/adios),[BORE](https://github.com/firelzrd/bore),[Cambyses](https://github.com/firelzrd/cambyses)移植(可选补丁)
- [x] CherryPick了部分上游提交，优化了调度器表现
- [x] 加入一些网络连接性能优化配置选项（用于为 ipset 及需要 iptables 等高级网络功能内核支持的程序提供支持）
- [x] Droidspaces 容器化支持（比传统 Docker/LXC 更轻量化，便于移植的完整 Linux 环境容器实现）
- [x] 添加了对[Mountify](https://github.com/backslashxx/mountify),[NoMount](https://github.com/maxsteeel/nomount),[HybridMount](https://github.com/Hybrid-Mount/meta-hybrid_mount)模块的支持
- [x] 加入Re:Kernel支持，与Freezer，NoActive等LSP模块配合降低功耗
- [x] 加入[BBG(By @showdo)](https://github.com/vc-teahouse/Baseband-guard)，有效防止恶意格机脚本/程序对系统分区的破坏
##### 
##### 
##### 
## 鸣谢
- BrokeStar233：[BrokeStar233](https://github.com/brokestar233)
- 🎧：[whitewhale0612](https://github.com/whitewhale0612)
- firelzrd：[firelzrd](https://github.com/firelzrd)
- WildKernel的一加系列内核构建脚本：[WildKernels/OnePlus_KernelSU_SUSFS](https://github.com/WildKernels/OnePlus_KernelSU_SUSFS)
- cctv18的欧加真米系列内核构建脚本：[oppo_oplus_realme_sm8850](https://github.com/cctv18/oppo_oplus_realme_sm8850)
- BakaSU：[BakaSU/BakaSU](https://github.com/ReSukiSU/ReSukiSU)
- SukiSU Ultra：[SukiSU-Ultra/SukiSU-Ultra](https://github.com/SukiSU-Ultra/SukiSU-Ultra)
- susfs4ksu：[ShirkNeko/susfs4ksu](https://github.com/ShirkNeko/susfs4ksu)
- pershoot维护的KernelSU Next仓库：[pershoot/KernelSU-Next](https://github.com/pershoot/KernelSU-Next)
- 原版KernelSU: [tiann/KernelSU](https://github.com/tiann/KernelSU)
- 内核防格基带保护模块：[vc-teahouse/Baseband-guard](https://github.com/vc-teahouse/Baseband-guard)
- KSUN的多管理器补丁：[WildKernels/kernel_patches](https://github.com/WildKernels/kernel_patches)

<!-- 这是一个访客统计，用来看看我的项目主页有多少人访问过 -->
<div align="center">
  <img width="0" height="0" src="https://count.getloli.com/get/@:edmory" />
</div>

